------------------------------------------------------------------------------------------
 boXplorer v0.96 BETA by T'ulkas August 16th 2002
------------------------------------------------------------------------------------------


** WARNING - PLEASE READ THIS **
------------------------------------------------------------------------------------------
This is a BETA release of boXplorer and has been tested on a PAL Xbox with a fittet Enigmah-X
chip and works fine, but the program *may* contain bugs so please use with caution.
Please read the Q & A below before installing and using this software !!!
Since boXplorer does not check that you don't delete or overwrite critical system files on
the Xbox harddrive and you can render your Xbox unusable if you are not carefull !!!
However, boXplorer gives you a clear warning before any file operations are performed so
it should not be possible to do anything critical by accident.
I highly recommend that you backup your entire Xbox harddrive to your PC (use Evolution X
and FTP) before you begin using boXplorer to manage files on the Xbox harddrive.
Using boXplorer is 100% at your own risk - the author (T'ulkas) cannot and will not be held
responsible for any loss of data or corrupting your Xbox in any way !



What is boXplorer ?
------------------------------------------------------------------------------------------

boXplorer is a file manager for Xbox which allows you to directly browse, copy, move, delete
and rename files and folders on the Xbox harddisk and DVD drive.
boXplorer can also play Xbox video media files (*.WMV) and launch other application or 
games (*.XBE files).
boXplorer can be booted from a DVD/CD or added to your Xbox harddrive and launched from there.
boXplorer is a great addition to Evolution X dashboard (on either harddrive or DVD/CD) since
it provides file manager capabilites which Evolution X currently lacks.
boXplorer contains file operations (copy, move, delete, rename and create folders) which makes
the program a fully functional file manager and for the first time makes it possible to manage
the files on the Xbox harddrive without Evolution X and FTP !
You can even use boXplorer to rip DVD games to the Xbox harddrive without having to copy
the files to your PC first.

I hope you'll like this tool :)



Installation
------------------------------------------------------------------------------------------

boXplorer can be used either on the Xbox harddisk with Evolution X or booted seperately
on a DVD/CD.

Installation on Xbox harddrive with Evolution X :

Start Evolution X on your Xbox. On your PC, FTP the Xbox like normal.
Create a new folder on the Xbox harddisk, I use "e:\boXplorer" myself.
Copy all files and sub-folders from the "Xbox Files" folder in the ZIP, to the folder on
the Xbox Hardisk. The Folder on the Xbox hardisk should look something like this :
  e:\boXplorer\Default.xbe
  e:\boXplorer\Media\back.xpr  
  e:\boXplorer\Media\font.xpr
Now you can add boXplorer to your Evolution X MENU.INI file. Consult the Evolution X
documentation for further info.


Installation on DVD/CD :

Burn the boXplorer.iso file on a DVD-R/DVD-RW or CD-R/CD-RW using your usual software.
If using Nero (like me) burn the ISO with these options : Finalize CD, Disk-At-Once.

If using CD-R/CD-RW and you are having problems, try to extract the files from
boXplorer.iso (I use the xISO tool) onto your PC, add a new sub-folder called "0dummy" and
add 500-600 MB worth of dummy files to this new folder, build a new ISO and burn it.
Sometimes the Xbox is having problems booting from a CD-R/CD-RW if the disk does not contain
enough data. It has something to do with the laser which like to read data from the outer
tracks on a CD-R/CD-RW more than the inner tracks. And this can be solved by adding some
dummy files in a "0dummy" folder which then is placed on inner tracks then the ISO is burned.
At least, that's my experiences :)



Instructions 
------------------------------------------------------------------------------------------

Warning :
Since boXplorer does not check that you don't delete or overwrite critical system files on
the Xbox harddrive and you can render your Xbox unusable if you are not carefull !!!
However, boXplorer gives you a clear warning before any file operations are performed so
it should not be possible to do anything critical by accident.
I highly recommend that you backup your entire Xbox harddrive to your PC (use Evolution X
and FTP) before you begin using boXplorer to manage files on the Xbox harddrive.
Using boXplorer is 100% at your own risk - the author (T'ulkas) cannot and will not be held
responsible for any loss of data or corrupting your Xbox in any way !

Panels :
boXplorer use the concept of "panels" to select source and destination for file operations.
There are two panels (A and B) which the user can switch between with left thumb button
(press down on the left analog stick) or left and right triggers - the letter "A" or "B" 
in the upper right corner of the screen indicates which panel is active.
The active panel (visible panel) is always considered as source and the inactive panel is
destination. Example : if the user has selected "e:\MyGames\Spider-Man\" on Panel A and
"d:\" on panel B and Panel B is visible/active, "d:\" is the source directory and
"e:\MyGames\Spider-Man\" is destination for file operations.
To select a drive for the current panel, activate the menu (press the white button) and select
"Select Drive" or press the Start button. You can use the same drive on both panels or use
different drives as source and destination.

Marking (selecting) files and folders :
To mark (select) files or folders for file operations (copy, move, delete, etc.) press the X
button to mark the file/folder under the cursor. When a file/folder is marked, the background
for the line will be a solid blue color. To remove the mark, simply press X again on the file/folder.
If you need to, you can also mark/unmark all files/folders in the current panel by selecting
"Mark All" or "Clear Marks" from the Main Menu (press White button to activate).

Copying files and folders :
To copy files with boXplorer, first select source and destination by switching between panel A
and B, selecting drive and folder on both panels. Then mark the files/folders you wish to copy
by marking (selecting) them on the source panel. When you have marked the files/folders you
wish to copy and the source panel is visible, press the white button to access the Main Menu and
select "Copy...". Now you should see a warning screen telling you what you are about to do.
Please read the information on the warning screen carefully before continuing.
To begin copying files/folders, hold both left and right triggers and press the start button.
NOTE : boXplorer currently does not check for available free space in destination folder, so
please check that you have enough free diskspace before beginning to copy files.
Also, if files exist on destination with the same name, they will be overwritten without warning !

Moving files and folders :
Moving files works very similar to copying files exept that files are removed from the source 
location after the files has been copied.
Other than that, the process of selecting files/folders, source and destination works in the
same way.
NOTE : boXplorer currently does not check for available free space in destination folder, so
please check that you have enough free diskspace before beginning to move files.
Also, if files exist on destination with the same name, they will be overwritten without warning !

Deleting files and folders :
Deleting files/folder is simpler to use since no selecting of destination is required.
Only files/folders selected on the active panel is deleted.
After marking the files/folder you wish to delete, simply select "Delete..." from the Main
Menu, read the warning screen carefully and begin deleting the files/folders by holding left and
right triggers and pressing the start button.

Rename files and folders:
The Rename operation is limited to only rename one file or folder at once so only mark one file
or folder when activating "Rename..." from the main menu.
When you have marked a file or folder for rename, you will be taken to a editor screen where
you can edit the name of the file or folder. Since there's no keyboard for the Xbox, all input
is done with the controller. Please read the "Controls" section in this file for button layout.
When you are finished entering the new name for the file or folder, press the Start button to
accept the new name or the Back button to cancel the rename.
When accepting (pressing the Start button) you will be taken to a warning screen where you must
hold left and right triggers and press the start button to proceed.

Create new folder :
This feature allows you to create a new folder (directory) on the Xbox harddrive.
Simply activate "New Folder..." from the Main Menu, enter a name for the new folder (please read
the info about renaming files/folders for further info about how to input a folder name), press
the Start button. On the warning screen, hold both triggers and press the start button to create
the folder.



Controls
------------------------------------------------------------------------------------------

Main screen :
A                      : Select folder/launch XBE/play WMV 
B                      : Go to parent folder.
X                      : Mark/unmark file/folder (for copy, move, delete, rename).
Y                      : Go to root folder.
BACK                   : Go to parent folder.
START                  : Select drive/partition.
WHITE                  : Open Main Menu
BLACK                  : Return to system dashboard.
D-PAD UP/DOWN          : Scroll up/down the list
D-PAD LEFT/RIGHT       : Scroll up/down the list, 1/2 screen.
LEFT STICK UP/DOWN     : Scroll up/down the list
LEFT TRIGGER           : Go to Panel A
RIGHT TRIGGER          : Go to Panel B
LEFT THUMB BUTTON      : Toggle between Panel A and Panel B.
RIGHT THUMB BUTTON     : Toggle file filter between "*.*", "*.XBE" and "*.WMV".

Main Menu :
START or A             : Select item	
B or X or Y or BACK    : Close menu.
BACK	               : Close menu.
D-PAD UP/DOWN          : Scroll up/down the list
LEFT STICK UP/DOWN     : Scroll up/down the list
BLACK                  : Return to system dashboard.

Select Drive screen :
START or A             : Select drive/partition
B or X or Y or BACK    : Cancel
D-PAD UP/DOWN          : Scroll up/down the list
LEFT STICK UP/DOWN     : Scroll up/down the list
BLACK                  : Return to system dashboard.

Edit Mode (used for Rename and New Folder features) :
BACK                   : Cancel
START                  : Accept
A                      : Insert space
B                      : Delete
X                      : Backspace
Y                      : Switch case
D-PAD UP/DOWN          : Select character
LEFT STICK UP/DOWN     : Select character
D-PAD LEFT/RIGHT       : Move cursor left/right
LEFT STICK LEFT/RIGHT  : Move cursor left/right
BLACK                  : Return to system dashboard.


While playing WMV files :
B                      : Stop playback



Q & A
------------------------------------------------------------------------------------------

Q : What is boxExplorer ?
A : A file manager for Xbox which enables you to browse and manage files on the Xbox harddrive.

A : Why use boXplorer when we can manage files on the Xbox harddrive thru FTP with Evolution X ?
Q : FTP with Evolution X is great but it requires you to have your Xbox connected to
    a PC and fiddling with IP addresses which may turn some people off. Also accidental deleting
    of files, etc. can easily happen when using FTP.
    But if you need an easy, fast and safe way to browse and manage file on the Xbox hardrive
    directly, boXplorer is the way ;)

Q : Can I use boXplorer as an dashboard replacement ?
A : NO DON'T EVEN TRY! But why would you anyway ? Use Evolution X or keep the standard one !

Q : What is Evolution X/xISO/Enigmah/whatever ?
A : If you don't know, maybe you shouldn't be messing around with this program ?

Q : Can I copy/delete/move/rename files with boXplorer ?
A : Yes, since version 0.95 you can :)
    boXplorer v0.95 introduced file operations (copy, move, delete, rename, etc.) and is now a
    fully functional file manager for the Xbox.

Q : I'm nervous about my Xbox, is boXplorer safe to use ?
A : Yes, it's completely safe as long as you don't copy, delete, move or rename files on the Xbox !
    But don't worry - you are given a clear warning before this happens, it should not be possible
    to copy, move, delete or rename files by accident !
    If you are nervous about installing boXplorer on the Xbox harddrive, you can easily burn
    it on a DVD/CD and boot it from there. Read the installation section for more info.

Q : There's a letter "A" (or "B") in the upper right corner of the screen, what's that ?
A : The letter "A" and "B" indicates which panel is active/visible.
    Read the Instructions section above for more info about panels. 

Q : What are those A and B panels ?
A : A way to select source and destination for file operations. If you are familiar with Norton
    Commander or Windows Commander you should feel right at home. The only difference is that
    boXplorer only have one panel visible (the active one).
    Read the Instructions section above for further info about panels. 

Q : What is "Marking files" ?
A : boXplorer can copy/move/delete multiple files and folders at the same time and to make this
    possible the files/folders must be marked (selected) so boXplorer "knows" what files/folders
    must be copied, moved or deleted.
    To mark (select) a file or folder, press the X button. Marked files/folders have a solid blue
    background color. Read the Instructions section above for further info about marking files/folders. 

Q : How do I copy/move/delete a file/folder ?
A : Read the Instructions section above. 

Q : How do I rename a file/folder ?
A : Read the Instructions section above. 

Q : How do I create a new folder (directory) ?
A : Read the Instructions section above. 

Q : I want to copy/move/delete/etc. files but nothing happens when I press the triggers and start button ?
A : First press and hold the left and right triggers and then press the start button.

Q : When running boXplorer, I can't FTP my Xbox ?
A : boXplorer does not contain FTP capabilities, use Evolution X to FTP your Xbox.

Q : Can I browse folders/files on my PC with boXplorer ?
A : No. You can ONLY browse your Xbox harddisk and DVD drive.

Q : Can copy/move/delete file to/from my PC and the Xbox harddrive ?
A : No, not in this version. If you wish to copy files between your PC and Xbox, please
    use Evolution X and FTP.

Q : Can I rip games from the DVD drive directly to the harddrive ?
A : Yes, simply select the DVD drive (d:) and copy the files from there to a new folder on the
    harddrive. But be sure you have enough free diskspace on the harddrive !

Q : Can I browse the internet with boXplorer ?
A : Nooooooo..... why did you have to ask ?!?!?!?!

Q : Can I add my own background/colors to boXplorer ?
A:  No, not right now. Maybe I will make support for customization in the future.

Q : When I eject the DVD drive to browse a game DVD, my Xbox resets ?
A:  This is normal on some Xbox mod-chips (I'm not an expert here) so if you want to
    browse a game DVD or rip files from it to the harddrive, insert the game DVD before
    launching boXplorer on the harddisk... using Evolution X of course :)

Q : I'm new at this Xbox hacking stuff... how do I get started ?
A : Check out the sites about the Xbox hacking scene and if you plan on copying stuff
    to your Xbox hardrive using Evolution X yourself, please be VERY carefull and
    remember to backup your Xbox harddrive before you start.
    If you screw up and your Xbox and it won't work properly, don't blame me !

Q : Have you anything to do with Evolution X ?
A : No, I don't even know the guys except from the scene forums and by their aliases.

Q : I can't get boXplorer to work on my Xbox ?
A : You need a chipped or otherwise modded Xbox which can use "unsigned code".
    boXplorer had been testet on a PAL Xbox with a Enigmah-X (final) chip, but it
    should work fine on other chips and US/NTSC Xbox consoles also.

Q : Can I get the source code anywhere ?
A:  No, at least not right now. Maybe I will release the source in the future.

Q : Is xboXplorer legal ?
A:  No, boXplorer was developed using Microsoft's Xbox Developer Kit (XDK) which
    is only legal to use for authorized and licenced Xbox developers. So by building
    my program with the XDK, my program contains MS XDK copyrighted code.
    I'm only a private person using this project to learn a bit about Xbox development.

Q : When is the next version coming out ?
A : I don't know... I REALLY don't... but soon I hope :)

Q : Where can I find the latest version of boXplorer ?
A : Hard to say since it's basicly illegal... but try Usenet (alt.binaries.cd.image.xbox)
    or IRC.

Q : Who are you ?
A : That's for me to know, T'ulkas is not my real name since I wish remain anonymous.

Q : How can I contact you with suggestions and such ?
A : Well you can't directly, but look out for me on the forums that are on the leading
    Xbox scene sites.

Q : What is Xbox ?
A : A pretty nice videogame console from Microsoft !

Q : What's the meaning of life ?
A : A chair, go figure...



Version history
------------------------------------------------------------------------------------

v0.96 BETA - Minor but important additions and improvements :

- BUGFIX: Rename function did not trim leading and trailing spaces.
- New file operation : "Calc. Used Space..."
- Rewritten Move file/folder function - now allowing moving folders across different drives.
- All file operations improved to give more accurate info on errors and success.
- Progress bar when copying/moving/deleting files.
- Drive Select and Main Menu selector now wraps.
- Use left analog stick or hold down D-Pad buttons to navigate thru lists, menues, editor, etc.
- Correctly display large free/total space on Drive Selection screen (for those big HDDs)
- "Exit to Dashboard" added to Main Menu.
- "Shutdown Xbox" added to Main Menu (thanks ausCoder!).
- On edit screen (Rename and New Folder functions) simple onscreen help is displayed.
- Automatic retry (3 times) on failed file copy - may help copy files from some bad DVDs/CDs. 
- And other cosmetic changes.


v0.95 BETA - Major update

- Introduction of file operations making boXplorer a real file manager :
  Copy multiple files/folders.
  Move multiple files/folders.
  Delete multiple files/folders.
  Rename single file or folder.
  Create new folder.
- Main Menu with file operations and other features (activate with WHITE button)
- Mark files for file operations (press X)
- "Mark All", "Clear Marks" and "Inverse Marks" in main menu to bulk-mark files.
- Panel A and Panel B - used like in Norton Commander or Windows Commander to select
  source and destination for file operations (toggle with left thumb button or trigger buttons).
- Select Drive function now shows free and total space on each drive.
- Button layout changed slightly to make room for new features.


v0.90 BETA - Initial release

- Browse files and folders on Xbox harddrive and DVD drive.
- Launch applications (*.XBE files)
- Play cut-scene videos (*.WMV files)



Still to come
------------------------------------------------------------------------------------

Features that may or may not be included in future releases :

- Multi-panel view (like Norton Commander and Windows Commander)
- New main menu.
- Improved browsing.
- Improved file operations :
  Check free space on destination.
  Press both triggers and Y button to cancel file operations.
  Option: Owerwrite existing files (yes/no)
  Option: Retry on error (0-5)
  Option: Stop on errors (yes/no)
- New file operation : "Copy As..."
- On-screen keyboard.
- Help
- Play more media formats (WAV, WMA, etc.)
- Connect to server (Windows PC).
- Customization (background, colors, fonts, etc.).



Credits/Greetings
------------------------------------------------------------------------------------

Pride for assisting with the graphics.
The Evolution X team for their great tool (still alive ?).
RUNTiME and d7o3g4q for their cool Xbox Media Player will B6 be out soon ?) and
helping out on the forums.");
Chossy, Lantus, Squirelly, ausCoder, Wishi, BadBeta, and all the other helpful
people on the scene forums.
Og til sidst en hilsen til de Danske Xbox ejere !


*END OF FILE*
